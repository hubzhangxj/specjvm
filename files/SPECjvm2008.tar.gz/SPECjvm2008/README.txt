
Building:
  You do not need to build SPECjvm2008 to run it.
  The user guide will describe how it is done if need be.

Running:    
  To run a compliant run:
    java -jar SPECjvm2008.jar

  To know how to configure, run:
    java -jar SPECjvm2008.jar --help

More documentation:
  See docs/index.html
