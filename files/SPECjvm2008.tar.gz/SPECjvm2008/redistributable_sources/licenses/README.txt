Document Title: README
  Last updated: 12 November 2007 aa
       Subject: Information about SPECjvm2008 original sources licenses
------------------------------------------------------------------------------

The redistributable_sources/licenses subdirectory on the SPECjvm2008
DVD-ROM contains copies of the licenses that cover the freely-available and
redistributable source archives or data files used for the SPECjvm2008 suite.

The following table lists the archives and data files, as well as the license or licenses that apply to them:

Archive name                      License
------------------------------------------------------------------------------
compiler.compiler                 GNU General Public License (GPL) Version 2 
                                  with the "Classpath" exception - see compiler.compiler/LICENSE
db-derby-10.3.1.4-src.zip         Apache License Version 2.0
javazoom.src.zip                  GNU Lesser General Public License V3
jcommon-1.0.9.zip                 GNU Lesser General Public License V3
jfreechart-1.0.5.zip              GNU Lesser General Public License V3
jtidy_src.zip                     License as documented in the file jtidy/LICENSE
sunflow-src-v0.07.2.zip           License as documented in the file sunflow/LICENSE.txt
xom-1.1-src.zip                   GNU Lesser General Public License V2.1

